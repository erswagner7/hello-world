﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.txtName = New System.Windows.Forms.TextBox()
        Me.txtYearsEmployed = New System.Windows.Forms.TextBox()
        Me.txtPrevPurchase = New System.Windows.Forms.TextBox()
        Me.txtTodayPurchase = New System.Windows.Forms.TextBox()
        Me.grpboxEmployeeInfo = New System.Windows.Forms.GroupBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.radHourly = New System.Windows.Forms.RadioButton()
        Me.radManage = New System.Windows.Forms.RadioButton()
        Me.grpboxEmployee = New System.Windows.Forms.GroupBox()
        Me.lblTodayPTotal = New System.Windows.Forms.Label()
        Me.lblEmpDiscP = New System.Windows.Forms.Label()
        Me.lblTodayP = New System.Windows.Forms.Label()
        Me.lblYTD = New System.Windows.Forms.Label()
        Me.lblEmpDisc = New System.Windows.Forms.Label()
        Me.lblName = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.btnCalc = New System.Windows.Forms.Button()
        Me.btnNxtEmp = New System.Windows.Forms.Button()
        Me.btnDisSum = New System.Windows.Forms.Button()
        Me.btnClose = New System.Windows.Forms.Button()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.grpboxEmployeeInfo.SuspendLayout()
        Me.grpboxEmployee.SuspendLayout()
        Me.SuspendLayout()
        '
        'txtName
        '
        Me.txtName.Location = New System.Drawing.Point(186, 27)
        Me.txtName.Name = "txtName"
        Me.txtName.Size = New System.Drawing.Size(179, 20)
        Me.txtName.TabIndex = 0
        '
        'txtYearsEmployed
        '
        Me.txtYearsEmployed.Location = New System.Drawing.Point(186, 67)
        Me.txtYearsEmployed.Name = "txtYearsEmployed"
        Me.txtYearsEmployed.Size = New System.Drawing.Size(179, 20)
        Me.txtYearsEmployed.TabIndex = 1
        '
        'txtPrevPurchase
        '
        Me.txtPrevPurchase.Location = New System.Drawing.Point(186, 105)
        Me.txtPrevPurchase.Name = "txtPrevPurchase"
        Me.txtPrevPurchase.Size = New System.Drawing.Size(179, 20)
        Me.txtPrevPurchase.TabIndex = 2
        '
        'txtTodayPurchase
        '
        Me.txtTodayPurchase.Location = New System.Drawing.Point(186, 148)
        Me.txtTodayPurchase.Name = "txtTodayPurchase"
        Me.txtTodayPurchase.Size = New System.Drawing.Size(179, 20)
        Me.txtTodayPurchase.TabIndex = 3
        '
        'grpboxEmployeeInfo
        '
        Me.grpboxEmployeeInfo.Controls.Add(Me.Label11)
        Me.grpboxEmployeeInfo.Controls.Add(Me.Label4)
        Me.grpboxEmployeeInfo.Controls.Add(Me.Label3)
        Me.grpboxEmployeeInfo.Controls.Add(Me.Label2)
        Me.grpboxEmployeeInfo.Controls.Add(Me.Label1)
        Me.grpboxEmployeeInfo.Controls.Add(Me.radHourly)
        Me.grpboxEmployeeInfo.Controls.Add(Me.radManage)
        Me.grpboxEmployeeInfo.Controls.Add(Me.txtName)
        Me.grpboxEmployeeInfo.Controls.Add(Me.txtTodayPurchase)
        Me.grpboxEmployeeInfo.Controls.Add(Me.txtYearsEmployed)
        Me.grpboxEmployeeInfo.Controls.Add(Me.txtPrevPurchase)
        Me.grpboxEmployeeInfo.Location = New System.Drawing.Point(12, 12)
        Me.grpboxEmployeeInfo.Name = "grpboxEmployeeInfo"
        Me.grpboxEmployeeInfo.Size = New System.Drawing.Size(376, 210)
        Me.grpboxEmployeeInfo.TabIndex = 4
        Me.grpboxEmployeeInfo.TabStop = False
        Me.grpboxEmployeeInfo.Text = "Employee Information"
        '
        'Label4
        '
        Me.Label4.Location = New System.Drawing.Point(7, 148)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(172, 20)
        Me.Label4.TabIndex = 9
        Me.Label4.Text = "Total of today’s purchase :"
        '
        'Label3
        '
        Me.Label3.Location = New System.Drawing.Point(7, 108)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(173, 30)
        Me.Label3.TabIndex = 8
        Me.Label3.Text = "Previous Purchases:"
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(7, 70)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(172, 23)
        Me.Label2.TabIndex = 7
        Me.Label2.Text = "Number of years employed:"
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(7, 30)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(172, 23)
        Me.Label1.TabIndex = 6
        Me.Label1.Text = "Name:"
        '
        'radHourly
        '
        Me.radHourly.Location = New System.Drawing.Point(296, 179)
        Me.radHourly.Name = "radHourly"
        Me.radHourly.Size = New System.Drawing.Size(69, 20)
        Me.radHourly.TabIndex = 5
        Me.radHourly.Text = "Hourly"
        Me.radHourly.UseVisualStyleBackColor = True
        '
        'radManage
        '
        Me.radManage.Checked = True
        Me.radManage.Location = New System.Drawing.Point(186, 179)
        Me.radManage.Name = "radManage"
        Me.radManage.Size = New System.Drawing.Size(87, 20)
        Me.radManage.TabIndex = 4
        Me.radManage.TabStop = True
        Me.radManage.Text = "Management"
        Me.radManage.UseVisualStyleBackColor = True
        '
        'grpboxEmployee
        '
        Me.grpboxEmployee.Controls.Add(Me.lblTodayPTotal)
        Me.grpboxEmployee.Controls.Add(Me.lblEmpDiscP)
        Me.grpboxEmployee.Controls.Add(Me.lblTodayP)
        Me.grpboxEmployee.Controls.Add(Me.lblYTD)
        Me.grpboxEmployee.Controls.Add(Me.lblEmpDisc)
        Me.grpboxEmployee.Controls.Add(Me.lblName)
        Me.grpboxEmployee.Controls.Add(Me.Label10)
        Me.grpboxEmployee.Controls.Add(Me.Label9)
        Me.grpboxEmployee.Controls.Add(Me.Label5)
        Me.grpboxEmployee.Controls.Add(Me.Label6)
        Me.grpboxEmployee.Controls.Add(Me.Label7)
        Me.grpboxEmployee.Controls.Add(Me.Label8)
        Me.grpboxEmployee.Location = New System.Drawing.Point(12, 228)
        Me.grpboxEmployee.Name = "grpboxEmployee"
        Me.grpboxEmployee.Size = New System.Drawing.Size(376, 250)
        Me.grpboxEmployee.TabIndex = 5
        Me.grpboxEmployee.TabStop = False
        Me.grpboxEmployee.Text = "Employee Display"
        '
        'lblTodayPTotal
        '
        Me.lblTodayPTotal.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblTodayPTotal.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblTodayPTotal.Location = New System.Drawing.Point(186, 196)
        Me.lblTodayPTotal.Name = "lblTodayPTotal"
        Me.lblTodayPTotal.Size = New System.Drawing.Size(179, 23)
        Me.lblTodayPTotal.TabIndex = 21
        '
        'lblEmpDiscP
        '
        Me.lblEmpDiscP.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblEmpDiscP.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblEmpDiscP.Location = New System.Drawing.Point(186, 161)
        Me.lblEmpDiscP.Name = "lblEmpDiscP"
        Me.lblEmpDiscP.Size = New System.Drawing.Size(179, 23)
        Me.lblEmpDiscP.TabIndex = 20
        '
        'lblTodayP
        '
        Me.lblTodayP.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblTodayP.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblTodayP.Location = New System.Drawing.Point(186, 131)
        Me.lblTodayP.Name = "lblTodayP"
        Me.lblTodayP.Size = New System.Drawing.Size(179, 23)
        Me.lblTodayP.TabIndex = 19
        '
        'lblYTD
        '
        Me.lblYTD.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblYTD.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblYTD.Location = New System.Drawing.Point(186, 91)
        Me.lblYTD.Name = "lblYTD"
        Me.lblYTD.Size = New System.Drawing.Size(179, 23)
        Me.lblYTD.TabIndex = 18
        '
        'lblEmpDisc
        '
        Me.lblEmpDisc.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblEmpDisc.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblEmpDisc.Location = New System.Drawing.Point(186, 59)
        Me.lblEmpDisc.Name = "lblEmpDisc"
        Me.lblEmpDisc.Size = New System.Drawing.Size(179, 23)
        Me.lblEmpDisc.TabIndex = 17
        '
        'lblName
        '
        Me.lblName.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblName.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblName.Location = New System.Drawing.Point(186, 27)
        Me.lblName.Name = "lblName"
        Me.lblName.Size = New System.Drawing.Size(179, 23)
        Me.lblName.TabIndex = 16
        '
        'Label10
        '
        Me.Label10.Location = New System.Drawing.Point(7, 196)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(174, 23)
        Me.Label10.TabIndex = 15
        Me.Label10.Text = "Today's Purchase Total:"
        '
        'Label9
        '
        Me.Label9.Location = New System.Drawing.Point(6, 161)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(174, 23)
        Me.Label9.TabIndex = 14
        Me.Label9.Text = "Employee Discount this Purchase:"
        '
        'Label5
        '
        Me.Label5.Location = New System.Drawing.Point(7, 131)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(145, 23)
        Me.Label5.TabIndex = 13
        Me.Label5.Text = "Today's Purchase:"
        '
        'Label6
        '
        Me.Label6.Location = New System.Drawing.Point(7, 91)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(135, 23)
        Me.Label6.TabIndex = 12
        Me.Label6.Text = "YTD Previous Discounts:"
        '
        'Label7
        '
        Me.Label7.Location = New System.Drawing.Point(7, 59)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(135, 23)
        Me.Label7.TabIndex = 11
        Me.Label7.Text = "Employee Discount:"
        '
        'Label8
        '
        Me.Label8.Location = New System.Drawing.Point(7, 27)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(135, 23)
        Me.Label8.TabIndex = 10
        Me.Label8.Text = "Name:"
        '
        'btnCalc
        '
        Me.btnCalc.Location = New System.Drawing.Point(20, 488)
        Me.btnCalc.Name = "btnCalc"
        Me.btnCalc.Size = New System.Drawing.Size(75, 50)
        Me.btnCalc.TabIndex = 7
        Me.btnCalc.Text = "Calculate"
        Me.btnCalc.UseVisualStyleBackColor = True
        '
        'btnNxtEmp
        '
        Me.btnNxtEmp.Location = New System.Drawing.Point(116, 488)
        Me.btnNxtEmp.Name = "btnNxtEmp"
        Me.btnNxtEmp.Size = New System.Drawing.Size(75, 50)
        Me.btnNxtEmp.TabIndex = 8
        Me.btnNxtEmp.Text = "Next Employee"
        Me.btnNxtEmp.UseVisualStyleBackColor = True
        '
        'btnDisSum
        '
        Me.btnDisSum.Location = New System.Drawing.Point(212, 488)
        Me.btnDisSum.Name = "btnDisSum"
        Me.btnDisSum.Size = New System.Drawing.Size(75, 50)
        Me.btnDisSum.TabIndex = 9
        Me.btnDisSum.Text = "Discount Summary"
        Me.btnDisSum.UseVisualStyleBackColor = True
        '
        'btnClose
        '
        Me.btnClose.Location = New System.Drawing.Point(308, 488)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(75, 50)
        Me.btnClose.TabIndex = 10
        Me.btnClose.Text = "Close"
        Me.btnClose.UseVisualStyleBackColor = True
        '
        'Label11
        '
        Me.Label11.Location = New System.Drawing.Point(7, 179)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(90, 20)
        Me.Label11.TabIndex = 10
        Me.Label11.Text = "Employee Status:"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(407, 561)
        Me.Controls.Add(Me.btnClose)
        Me.Controls.Add(Me.btnDisSum)
        Me.Controls.Add(Me.btnNxtEmp)
        Me.Controls.Add(Me.btnCalc)
        Me.Controls.Add(Me.grpboxEmployee)
        Me.Controls.Add(Me.grpboxEmployeeInfo)
        Me.Name = "Form1"
        Me.Text = "Employee Discount Application"
        Me.grpboxEmployeeInfo.ResumeLayout(False)
        Me.grpboxEmployeeInfo.PerformLayout()
        Me.grpboxEmployee.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents txtName As System.Windows.Forms.TextBox
    Friend WithEvents txtYearsEmployed As System.Windows.Forms.TextBox
    Friend WithEvents txtPrevPurchase As System.Windows.Forms.TextBox
    Friend WithEvents txtTodayPurchase As System.Windows.Forms.TextBox
    Friend WithEvents grpboxEmployeeInfo As System.Windows.Forms.GroupBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents radHourly As System.Windows.Forms.RadioButton
    Friend WithEvents radManage As System.Windows.Forms.RadioButton
    Friend WithEvents grpboxEmployee As System.Windows.Forms.GroupBox
    Friend WithEvents btnCalc As System.Windows.Forms.Button
    Friend WithEvents btnNxtEmp As System.Windows.Forms.Button
    Friend WithEvents btnDisSum As System.Windows.Forms.Button
    Friend WithEvents btnClose As System.Windows.Forms.Button
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents lblName As System.Windows.Forms.Label
    Friend WithEvents lblTodayPTotal As System.Windows.Forms.Label
    Friend WithEvents lblEmpDiscP As System.Windows.Forms.Label
    Friend WithEvents lblTodayP As System.Windows.Forms.Label
    Friend WithEvents lblYTD As System.Windows.Forms.Label
    Friend WithEvents lblEmpDisc As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label

End Class
