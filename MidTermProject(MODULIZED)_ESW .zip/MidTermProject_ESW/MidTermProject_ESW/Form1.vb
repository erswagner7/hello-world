﻿Option Strict On
Public Class Form1
    'Name: Erich Wagner
    'Class: .Net Programming
    'Abstract: MidTerm Project (Modulized)



    'Calculate Procedures
    '====================

    'validate (Name, Years employed, Previous purchase, todays purchase)

    'Calculate (employee discount, YTD previous discount, Discount price, Todays price total, total before discount, total with discount)


    'Declare variables

    'input variables

    Dim dblTodayP As Double

    Dim dblTodayPTotal As Double

    'Discount Summary Variables
    Dim dblTotalBeforeDisc As Double
    Dim dblTotalWithDisc As Double
    Private Sub btnCalc_Click(sender As Object, e As EventArgs) Handles btnCalc.Click


        Dim strName As String
        Dim shtYearEmp As Short
        Dim dblPrevPurchase As Double


        'output variables
        Dim dblEmployeeDisc As Double
        Dim dblYTDPrevDisc As Double
        Dim dblEmpDiscP As Double




        Dim blnValidated As Boolean = True

        'Calls procedure to validate the textboxes
        Call ValidateInputs(strName, shtYearEmp, dblPrevPurchase, dblTodayP, blnValidated)

        'only works if the input is valid
        If blnValidated Then

            'calls for the calculation procedures
            '====================================

            Call CalculateEmployeeDiscount(shtYearEmp, dblEmployeeDisc)

            Call CalculateYTD(dblYTDPrevDisc, dblEmpDiscP, dblPrevPurchase, dblEmployeeDisc, dblTodayP)

            Call CalculateTodayPurchaseTotal(dblTodayP, dblEmpDiscP, dblTodayPTotal)

            'calls for the display procedure
            Call DisplayEmployeeSummary(dblTodayP, strName, dblEmployeeDisc, dblYTDPrevDisc, dblEmpDiscP,
                                        dblTodayPTotal, dblTotalBeforeDisc, dblTotalWithDisc)

        End If

        





    End Sub

    Private Sub ValidateInputs(ByRef Name As String, ByRef YearEmployed As Short,
                               ByRef PreviousPurchase As Double, ByRef TodayPurchase As Double, ByRef Validated As Boolean)
        'validates the input to avoid user error

        'validating name
        '==================
        If txtName.Text = "" Then
            MessageBox.Show("Please enter the employee's name")
        Else
            Name = txtName.Text
        End If

        'validating years employed
        '==========================
        If txtYearsEmployed.Text = "" Then
            MessageBox.Show("Please enter the years employed")
        Else
            If IsNumeric(txtYearsEmployed.Text) Then
                YearEmployed = CShort(txtYearsEmployed.Text)
                If YearEmployed < 0 Then
                    MessageBox.Show("The years employed must be positive")
                    Validated = False
                End If
            Else
                MessageBox.Show("The years employed must be numeric")
                Validated = False
            End If
        End If


        'validating previous purchase
        '=============================
        If txtPrevPurchase.Text = "" Then
            MessageBox.Show("Please enter the cost of the previous purchase")
        Else
            If IsNumeric(txtPrevPurchase.Text) Then
                PreviousPurchase = CDbl(txtPrevPurchase.Text)
                If PreviousPurchase < 0 Then
                    MessageBox.Show("The previous purchase must be positive")
                    Validated = False
                End If
            Else
                MessageBox.Show("The previous purchase must be numeric")
                Validated = False
            End If
        End If

        'validating today's purchase
        '=============================
        If txtTodayPurchase.Text = "" Then
            MessageBox.Show("Please enter the cost of today's purchase")
        Else
            If IsNumeric(txtTodayPurchase.Text) Then
                TodayPurchase = CDbl(txtTodayPurchase.Text)
                If TodayPurchase < 0 Then
                    MessageBox.Show("Today's purchase must be positive")
                    Validated = False
                End If
            Else
                MessageBox.Show("Today's purchase must be numeric")
                Validated = False
            End If
        End If

    End Sub

    Private Function CalculateEmployeeDiscount(ByVal YearsEmployed As Short, ByRef EmployeeDiscount As Double) As Double

        'Employee Discount Standard
        'Years of Employement           Management          Hourly
        '----------------------          ----------          ------
        '1-3 years                      20%                 10%
        '4-6 years                      24%                 14%
        '7-10 years                     30%                 20%
        '11-15 years                    35%                 25%
        'more than 15 years             40%                 30%

        'Employee discount this purchase = total purchase today * discount if < $200. 
        'If over $200 previously no discount. If less than $200 prior to today but today takes them over $200 then
        ' only allow the amount to get them to $200.
        'Total with discount = Total * discount allowed


        'Employee Discount Standard calculations

        'Years 1-3
        If YearsEmployed >= 1 And YearsEmployed <= 3 Then
            If radManage.Checked = True Then
                lblEmpDisc.Text = "20%"
                EmployeeDiscount = 0.2
            Else
                If radHourly.Checked = True Then
                    lblEmpDisc.Text = "10%"
                    EmployeeDiscount = 0.1
                End If
            End If
        End If

        'Years 4-6
        If YearsEmployed >= 4 And YearsEmployed <= 6 Then
            If radManage.Checked = True Then
                lblEmpDisc.Text = "24%"
                EmployeeDiscount = 0.24
            Else
                If radHourly.Checked = True Then
                    lblEmpDisc.Text = "14%"
                    EmployeeDiscount = 0.14
                End If
            End If
        End If

        'Years 7-10
        If YearsEmployed >= 7 And YearsEmployed <= 10 Then
            If radManage.Checked = True Then
                lblEmpDisc.Text = "30%"
                EmployeeDiscount = 0.3
            Else
                If radHourly.Checked = True Then
                    lblEmpDisc.Text = "20%"
                    EmployeeDiscount = 0.2
                End If
            End If
        End If

        'Years 11-15
        If YearsEmployed >= 11 And YearsEmployed <= 15 Then
            If radManage.Checked = True Then
                lblEmpDisc.Text = "35%"
                EmployeeDiscount = 0.35
            Else
                If radHourly.Checked = True Then
                    lblEmpDisc.Text = "25%"
                    EmployeeDiscount = 0.25
                End If
            End If
        End If

        'Years >15
        If YearsEmployed >= 15 Then
            If radManage.Checked = True Then
                lblEmpDisc.Text = "40%"
                EmployeeDiscount = 0.4
            Else
                If radHourly.Checked = True Then
                    lblEmpDisc.Text = "30%"
                    EmployeeDiscount = 0.3
                End If
            End If
        End If


        Return EmployeeDiscount
    End Function

    Private Function CalculateYTD(ByRef YTDPrevDisc As Double, ByRef EmpDiscP As Double, ByVal PrevPurchase As Double,
                                  ByVal EmployeeDiscount As Double, ByVal TodaysPurchase As Double) As Double
        'YTD previous discount
        YTDPrevDisc = PrevPurchase * EmployeeDiscount
        EmpDiscP = TodaysPurchase * EmployeeDiscount

        'No total discount above $200
        If YTDPrevDisc >= 200 Then
            EmpDiscP = 0
            YTDPrevDisc = 200
        End If

        If YTDPrevDisc < 200 And YTDPrevDisc + EmpDiscP > 200 Then
            EmpDiscP = 200 - YTDPrevDisc
        End If

        If YTDPrevDisc < 200 And YTDPrevDisc + EmpDiscP <= 200 Then
            EmpDiscP = EmpDiscP
            YTDPrevDisc = YTDPrevDisc
        End If


        Return YTDPrevDisc
    End Function

    Private Function CalculateTodayPurchaseTotal(ByVal TodaysPurchase As Double, ByVal EmployeeDiscountPurchase As Double,
                                                 ByRef TodayPurchaseTotal As Double) As Double
        ' dblYTDPrevDisc YTD discount
        'YTD discount in dollars = total purchase before today * discount
        TodayPurchaseTotal = TodaysPurchase - EmployeeDiscountPurchase

        Return TodayPurchaseTotal
    End Function


    Private Sub DisplayEmployeeSummary(ByVal TodaysPurchase As Double, ByVal Name As String, ByVal EmployeeDiscount As Double,
                                       ByVal YTDPreviousDiscount As Double, ByVal EmployeeDiscountPurchase As Double,
                                       ByVal TodayPurchaseTotal As Double, ByVal TotalBeforeDisc As Double,
                                       ByVal TotalWithDisc As Double)

        'name
        lblName.Text = Name

        'todays purchase
        lblTodayP.Text = TodaysPurchase.ToString("c")

        'YTD previous discount
        lblYTD.Text = YTDPreviousDiscount.ToString("c")

        'employee discount purchase
        lblEmpDiscP.Text = EmployeeDiscountPurchase.ToString("c")

        'today purchase total
        lblTodayPTotal.Text = TodayPurchaseTotal.ToString("c")

    End Sub
    Private Sub btnNxtEmp_Click(sender As Object, e As EventArgs) Handles btnNxtEmp.Click
        'Clears current employee for next employee
        'input
        txtName.Clear()
        txtPrevPurchase.Clear()
        txtTodayPurchase.Clear()
        txtYearsEmployed.Clear()
        radManage.Checked = True
        radHourly.Checked = False
        txtName.Focus()

        'output
        lblName.ResetText()
        lblEmpDisc.ResetText()
        lblYTD.ResetText()
        lblTodayP.ResetText()
        lblEmpDiscP.ResetText()
        lblTodayPTotal.ResetText()
    End Sub

    Private Sub btnDisSum_Click(sender As Object, e As EventArgs) Handles btnDisSum.Click
        'Discount Summary


        'Daily total before discount dblTotalBeforeDisc  lblTotalBeforeDisc
        dblTotalBeforeDisc += dblTodayP
        'Daily total with discount  dblTotalWithDisc  lblTotalAfterDisc
        dblTotalWithDisc += dblTodayPTotal
        MessageBox.Show("The daily total before the discount is " + dblTotalBeforeDisc.ToString("c") + "." + " The daily total with the discount is " + dblTotalWithDisc.ToString("c") + ".")

        dblTodayP = 0
        dblTodayPTotal = 0
    End Sub


    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        'closes the form
        Close()

    End Sub
End Class




'Original code
'==============   
'Option Strict On
'Public Class Form1
'    'Name: Erich Wagner
'    'Class: .Net Programming
'    'Abstract: MidTerm Project (Original)

'    'Declare variables

'    'input variables
'    Dim strName As String
'    Dim shtYearEmp As Short
'    Dim PrevPurchase As Double
'    Dim dblTodayP As Double

'    'output variables
'    Dim dblEmployeeDisc As Double
'    Dim dblYTDPrevDisc As Double
'    Dim dblEmpDiscP As Double
'    Dim dblTodayPTotal As Double

'    'Discount Summary Variables
'    Dim dblTotalBeforeDisc As Double
'    Dim dblTotalWithDisc As Double

'    Private Sub btnCalc_Click(sender As Object, e As EventArgs) Handles btnCalc.Click


'        'name
'        strName = txtName.Text
'        lblName.Text = strName


'        'Employee Discount Standard
'        'Years of Employement           Management          Hourly
'        '----------------------          ----------          ------
'        '1-3 years                      20%                 10%
'        '4-6 years                      24%                 14%
'        '7-10 years                     30%                 20%
'        '11-15 years                    35%                 25%
'        'more than 15 years             40%                 30%

'        'Employee discount this purchase = total purchase today * discount if < $200. 
'        'If over $200 previously no discount. If less than $200 prior to today but today takes them over $200 then only
' allow the amount to get them to $200.
'        'Total with discount = Total * discount allowed


'        'Employee Discount Standard calculations

'        If Short.TryParse(txtYearsEmployed.Text, shtYearEmp) = True Then
'        Else
'            MessageBox.Show("Please enter in a valid number")
'            txtYearsEmployed.Clear()
'            Exit Sub
'        End If

'        'Years 1-3
'        If shtYearEmp >= 1 And shtYearEmp <= 3 Then
'            If radManage.Checked = True Then
'                lblEmpDisc.Text = "20%"
'                dblEmployeeDisc = 0.2
'            Else
'                If radHourly.Checked = True Then
'                    lblEmpDisc.Text = "10%"
'                    dblEmployeeDisc = 0.1
'                End If
'            End If
'        End If

'        'Years 4-6
'        If shtYearEmp >= 4 And shtYearEmp <= 6 Then
'            If radManage.Checked = True Then
'                lblEmpDisc.Text = "24%"
'                dblEmployeeDisc = 0.24
'            Else
'                If radHourly.Checked = True Then
'                    lblEmpDisc.Text = "14%"
'                    dblEmployeeDisc = 0.14
'                End If
'            End If
'        End If

'        'Years 7-10
'        If shtYearEmp >= 7 And shtYearEmp <= 10 Then
'            If radManage.Checked = True Then
'                lblEmpDisc.Text = "30%"
'                dblEmployeeDisc = 0.3
'            Else
'                If radHourly.Checked = True Then
'                    lblEmpDisc.Text = "20%"
'                    dblEmployeeDisc = 0.2
'                End If
'            End If
'        End If

'        'Years 11-15
'        If shtYearEmp >= 11 And shtYearEmp <= 15 Then
'            If radManage.Checked = True Then
'                lblEmpDisc.Text = "35%"
'                dblEmployeeDisc = 0.35
'            Else
'                If radHourly.Checked = True Then
'                    lblEmpDisc.Text = "25%"
'                    dblEmployeeDisc = 0.25
'                End If
'            End If
'        End If

'        'Years >15
'        If shtYearEmp >= 15 Then
'            If radManage.Checked = True Then
'                lblEmpDisc.Text = "40%"
'                dblEmployeeDisc = 0.4
'            Else
'                If radHourly.Checked = True Then
'                    lblEmpDisc.Text = "30%"
'                    dblEmployeeDisc = 0.3
'                End If
'            End If
'        End If

'        'Previous purchases
'        If Double.TryParse(txtPrevPurchase.Text, dblPrevPurchase) = True Then
'        Else
'            MessageBox.Show("Please enter in a valid number")
'        End If

'        'today's purchase
'        If Double.TryParse(txtTodayPurchase.Text, dblTodayP) = True Then
'            lblTodayP.Text = dblTodayP.ToString("c")
'        Else
'            MessageBox.Show("Please enter in a valid number")
'            txtTodayPurchase.Clear()
'        End If

'        'YTD previous discount
'        dblYTDPrevDisc = dblPrevPurchase * dblEmployeeDisc
'        dblEmpDiscP = dblTodayP * dblEmployeeDisc

'        'No total discount above $200
'        If dblYTDPrevDisc >= 200 Then
'            dblEmpDiscP = 0
'            dblYTDPrevDisc = 200
'        End If

'        If dblYTDPrevDisc < 200 And dblYTDPrevDisc + dblEmpDiscP > 200 Then
'            dblEmpDiscP = 200 - dblYTDPrevDisc
'        End If

'        If dblYTDPrevDisc < 200 And dblYTDPrevDisc + dblEmpDiscP <= 200 Then
'            dblEmpDiscP = dblEmpDiscP
'            dblYTDPrevDisc = dblYTDPrevDisc
'        End If


'        lblYTD.Text = dblYTDPrevDisc.ToString("c")
'        lblEmpDiscP.Text = dblEmpDiscP.ToString("c")
'        ' dblYTDPrevDisc YTD discount
'        'YTD discount in dollars = total purchase before today * discount
'        dblTodayPTotal = dblTodayP - dblEmpDiscP
'        lblTodayPTotal.Text = dblTodayPTotal.ToString("c")

'    End Sub

'    Private Sub btnNxtEmp_Click(sender As Object, e As EventArgs) Handles btnNxtEmp.Click
'        'Clears current employee for next employee
'        'input
'        txtName.Clear()
'        txtPrevPurchase.Clear()
'        txtTodayPurchase.Clear()
'        txtYearsEmployed.Clear()
'        radManage.Checked = True
'        radHourly.Checked = False
'        txtName.Focus()

'        'output
'        lblName.ResetText()
'        lblEmpDisc.ResetText()
'        lblYTD.ResetText()
'        lblTodayP.ResetText()
'        lblEmpDiscP.ResetText()
'        lblTodayPTotal.ResetText()
'    End Sub

'    Private Sub btnDisSum_Click(sender As Object, e As EventArgs) Handles btnDisSum.Click
'        'Discount Summary


'        'Daily total before discount dblTotalBeforeDisc  lblTotalBeforeDisc
'        dblTotalBeforeDisc += dblTodayP
'        'Daily total with discount  dblTotalWithDisc  lblTotalAfterDisc
'        dblTotalWithDisc += dblTodayPTotal
'        MessageBox.Show("The daily total before the discount is " + dblTotalBeforeDisc.ToString("c") + "." + " The daily total with the discount is " + dblTotalWithDisc.ToString("c") + ".")

'        dblTodayP = 0
'        dblTodayPTotal = 0
'    End Sub


'    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
'        'closes the form
'        Close()

'    End Sub
'End Class
